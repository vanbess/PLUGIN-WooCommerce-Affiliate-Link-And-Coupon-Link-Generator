<?php
/* * *********************************** */
/* * ADMIN PAGE FOR GENERATING LINKS* */
/* * *********************************** */

function sbwcaff_register_admin_page() {

    add_submenu_page(
        'edit.php?post_type=coupon_link',
        __( 'Generate Coupon/Discount Link', 'woocommerce' ),
        __( 'Coupon Link Generator', 'woocommerce' ),
        'manage_options',
        'sbwaff-settings',
        'sbwcaff_settings',
        1
    );

}

add_action( 'admin_menu', 'sbwcaff_register_admin_page' );

// callback/display function
function sbwcaff_settings() {
    ?>
    <div id="sbwcaff_settings">

        <h3><?php _e( 'Coupon Link Generator' ); ?></h3>

        <div id="sbwcaff-settings-input-cont">
            <p><?php _e( 'Use the inputs below to generate your coupon link. Once generated you can save the link for later reference.' ); ?></p>

            <!-- product slug -->
            <input type="text" name="pslug" id="pslug" placeholder="<?php _e( 'product slug*' ); ?>">

            <!-- affiliate id -->
            <input type="text" name="affid" id="affid" placeholder="<?php _e( 'affiliate id*' ); ?>">

            <!-- discount -->
            <input type="number" name="discount" id="discount" placeholder="<?php _e( 'discount percentage*' ); ?>">

            <?php
            //get wc permalink structure
            $wc_permalinks = maybe_unserialize( get_option( 'woocommerce_permalinks' ) );
            ?>

            <!-- generate -->
            <button id="sbwcaff-gen-link" data-shop-base="<?php echo site_url(); ?>" data-product-base="<?php echo $wc_permalinks[ 'product_base' ]; ?>/" class="button"><?php _e( 'Generate' ); ?></button>

            <!-- generated link -->
            <input type="text" name="generated" id="generated" placeholder="<?php _e( 'generated link will appear here' ); ?>">

            <!-- save link -->
            <button id="sbwcaff-save-link" data-aju="<?php echo admin_url( 'admin-ajax.php' ); ?>" class="button button-primary"><?php _e( 'Save Link' ); ?></button>
        </div>
    </div>
    <?php
}

/* * ****************************** */
/* * SAVE GENERATED LINK VIA AJAX* */
/* * ****************************** */
add_action( 'wp_ajax_sbwcaff_save_genned_link', 'sbwcaff_save_genned_link' );
add_action( 'wp_ajax_nopriv_sbwcaff_save_genned_link', 'sbwcaff_save_genned_link' );

function sbwcaff_save_genned_link() {
    if ( $_POST[ 'action' ] == 'sbwcaff_save_genned_link' ) :

        //print_r($_POST);

        $link_inserted = wp_insert_post( [
                'post_type'    => 'coupon_link',
                'post_status'  => 'publish',
                'post_author'  => '',
                'post_title'   => htmlentities( $_POST[ 'link' ] ),
                'post_content' => '',
                'meta_input'   => [
                        '_date_used' => '',
                        '_coupon_id' => ''
                ]
            ] );

        if ( $link_inserted ) :
            _e( 'Link has been saved. Once used the associated coupon ID will be attached to it for tracking purposes.' );
        else :
            _e( 'Link could not be saved. Please try again once the page has reloaded.' );
        endif;

    endif;
    wp_die();
}
?>